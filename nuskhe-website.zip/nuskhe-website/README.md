# Nuskhe — Ayurveda Home Remedies (Website)

A single-page website cataloguing traditional Ayurvedic home remedies,
searchable by symptom or by ingredients you have at home. Built with
plain HTML, CSS, and JavaScript — no backend, no build step, no
dependencies to install.

## Features
- Search by symptom
- "What's in your kitchen?" — filter by ingredients you have
- Browse by category
- Remedy of the day
- Ingredient glossary noting which herbs are documented in classical
  Ayurvedic texts (Charaka Samhita, Sushruta Samhita) versus passed
  down as household tradition

## Run it locally
Just open `index.html` in any browser — no setup needed.

## View it live
This site is set up for GitHub Pages. Once pushed to GitHub:
1. Go to your repo's **Settings → Pages**
2. Under "Build and deployment", set **Source** to `Deploy from a branch`
3. Choose the `main` branch and `/ (root)` folder, then **Save**
4. Your live link will appear at the top of that page within a minute or two,
   usually `https://<your-username>.github.io/<repo-name>/`

## Disclaimer
These are traditional home remedies for everyday, mild discomfort —
not a substitute for medical advice. For anything severe or persistent,
see a doctor. For personalised Ayurvedic guidance, consult a
BAMS-qualified Ayurvedic doctor.
